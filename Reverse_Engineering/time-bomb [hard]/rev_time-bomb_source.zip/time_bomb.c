#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

time_t SEED;

void init() {
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  setbuf(stderr, NULL);
  SEED = time(0);
  srand(SEED);
}

size_t get_length(FILE *fp) {
  fseek(fp, 0, SEEK_END);
  size_t ret = ftell(fp);
  rewind(fp);
  return ret;
}

void check_malloc_fail(void *p) {
  if (p == NULL) {
    fprintf(stderr, "malloc failed. Aborting...\n");
    exit(EXIT_FAILURE);
  }
}

char *read_contents(FILE *fp, size_t length) {
  char *ret = malloc(length);
  check_malloc_fail(ret);
  fread(ret, length, 1, fp);
  return ret;
}

char *generate_key(size_t length) {
  char *ret = malloc(length);
  check_malloc_fail(ret);
  for (int i = 0; i < length; i++) {
    ret[i] = rand() % 0xff;
  }
  return ret;
}

char *xor_cipher(char *a, char *b, size_t n) {
  char *ret = malloc(n);
  check_malloc_fail(ret);
  for (int i = 0; i < n; i++) {
    ret[i] = a[i] ^ b[i];
  }
  return ret;
}

void write_contents(char *filename, char *enc, size_t length) {
  char *dst = malloc(strlen(filename) + 5);
  check_malloc_fail(dst);
  strncpy(dst, filename, strlen(filename));
  dst[strlen(filename) + 0] = '.';
  dst[strlen(filename) + 1] = 'e';
  dst[strlen(filename) + 2] = 'n';
  dst[strlen(filename) + 3] = 'c';
  dst[strlen(filename) + 4] = '\0';
  char *output = malloc(length + 4);
  check_malloc_fail(output);
  char *seed_bytes = (char *)&SEED;
  memcpy(output + 0, seed_bytes, 2);
  memcpy(output + 2, enc, length);
  memcpy(output + 2 + length, seed_bytes + 2, 2);
  FILE *fp = fopen(dst, "w+");
  fwrite(output, length + 4, 1, fp);
  printf("[+] Saved encrypted file to '%s'\n", dst);
  fclose(fp);
  free(output);
  free(dst);
}

int main(int argc, char **argv) {
  if (argc != 2) {
    fprintf(stderr, "Usage : %s <file>\n", argv[0]);
    exit(EXIT_FAILURE);
  }
  init();
  FILE *fp = fopen(argv[1], "r");
  if (fp == NULL) {
    fprintf(stderr, "Could not open file '%s'\n", argv[1]);
    exit(EXIT_FAILURE);
  }
  size_t length = get_length(fp);
  char *contents = read_contents(fp, length);
  fclose(fp);
  char *key = generate_key(length);
  char *enc = xor_cipher(contents, key, length);
  write_contents(argv[1], enc, length);
  free(enc);
  free(key);
  free(contents);
  return EXIT_SUCCESS;
}
