#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

time_t SEED;

size_t get_length(FILE *fp) {
  fseek(fp, 0, SEEK_END);
  size_t ret = ftell(fp);
  rewind(fp);
  return ret;
}

int main(void) {
  FILE *fp = fopen("flag.txt.enc", "r");
  size_t length = get_length(fp);
  char *data = malloc(length - 4);
  if (data == NULL) {
    fprintf(stderr, "malloc failed\n");
    return EXIT_FAILURE;
  }
  fread(&SEED, 2, 1, fp);
  fread(data, length - 4, 1, fp);
  fread((void *)&SEED + 2, 2, 1, fp);
  srand(SEED);
  for (int i = 0; i < length - 4; i++) {
    data[i] ^= rand() % 0xff;
  }
  write(STDOUT_FILENO, data, length - 4);
  free(data);
  fclose(fp);
}
