#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

void init() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
}

char *packed =
    "\xf1\x3e\x7c\x2d\x45\x04\x00\xf1\x35\x36\x7f\x28\x0c\x7a\x36\x77\x15\x1c"
    "\xf4\x1a\x22\x7b\x28\x75\x27\x2f\x10\x00\x0d\xec\x33\x2d\x21\x70\x28\x75"
    "\x3d\x7b\x04\x0f\xfd\x10\x06\x16\x08\x18\x04\x07\x08\x18\xf6\x73\x45\x54"
    "\x48\x01\xda\xa2\xc5\x5a\x6b\x50\x21\x51\x0d\xab\x8a\x0d\xbe\x8c\x0d\xbb"
    "\x80\x00\xcc\xa9\x45\x2b\xa3\xf1\x52\x44\x4f\x45\xb8\x4b\xec\x47\x45\x54"
    "\x4c\x1e\x1a\x10\x1e\x1f\x8a";

char *key = "IHOPETHISDOESNTGETLEAKED";

#define PACKED_LEN 97

void populate_memory(char *mem) {
  int n = strlen(key);
  for (int i = 0; i < PACKED_LEN; i++) {
    mem[i] = packed[i] ^ key[i % n];
  }
}

int main(int argc, char **argv) {
  if (argc != 2) {
    printf("Usage: %s <FLAG>\n", argv[0]);
    return EXIT_FAILURE;
  }
  init();
  char *mem = mmap(NULL, PACKED_LEN, PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_ANON | MAP_PRIVATE, -1, 0);
  if (mem == MAP_FAILED) {
    puts("Uh oh your PC is out of memory. Sorry I cannot continue");
    return EXIT_FAILURE;
  }
  populate_memory(mem);
  int (*check_flag)(char *) = (void *)mem;
  if (strlen(argv[1]) == 35 && check_flag(argv[1])) {
    printf("Yup, you are good to go. Go head and submit %s\n", argv[1]);
  } else {
    puts("Oops! That's not right.");
  }
  munmap(mem, PACKED_LEN);
  return EXIT_SUCCESS;
}
