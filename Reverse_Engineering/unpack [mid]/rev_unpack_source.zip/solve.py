from pwn import *

context.binary = ELF('./unpack', checksec=False)

with open('./unpack', 'rb') as f:
    f.seek(0x2008)
    enc = f.read(0x61)

key = b'IHOPETHISDOESNTGETLEAKED'
code = xor(enc, key)
print(disasm(code))

print(p64(0x4143415349534a44).decode(), end='')
print(p64(0x356e30673472647b).decode(), end='')
print(p64(0x5f676e316d30635f).decode(), end='')
print(p64(0x3062345f6d307266).decode(), end='')
print(p64(0x7d3376).decode())
