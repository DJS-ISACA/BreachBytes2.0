#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

long long FIRST_HALF[15];
long long SECOND_HALF[15];

int main() {
  int fd = open("./recursion", O_RDONLY);
  pread(fd, &FIRST_HALF, sizeof(FIRST_HALF), 0x3060);
  pread(fd, &SECOND_HALF, sizeof(SECOND_HALF), 0x30e0);
  close(fd);
  for (int i = 0; i < 15; i++) {
    printf("%c", (char)FIRST_HALF[i]);
  }
  for (int i = 14; i >= 0; i--) {
    printf("%c", (char)SECOND_HALF[i]);
  }
  return 0;
}
