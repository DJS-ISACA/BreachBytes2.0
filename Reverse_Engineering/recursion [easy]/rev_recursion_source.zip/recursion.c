#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void init() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
}

unsigned long FIRST_HALF[] = {'D', 'J', 'S', 'I', 'S', 'A', 'C', 'A',
                              '{', '3', 'L', '!', 'X', '!', 'R'};
unsigned long SECOND_HALF[] = {'}', 'R', '!', 'X', '!', 'L', '3', 'K',
                               'R', '4', 'D', '>', '-', '-', '-'};

int validate_length(char *start, char *end) {
  int first_half_length = sizeof(FIRST_HALF) / sizeof(FIRST_HALF[0]);
  int second_half_length = sizeof(SECOND_HALF) / sizeof(SECOND_HALF[0]);
  return end - start + 1 == first_half_length + second_half_length;
}

int validate_chars(char *start, char *end, size_t i) {
  if (start > end) {
    return 1;
  }
  return *start == FIRST_HALF[i] && *end == SECOND_HALF[i] &&
         validate_chars(start + 1, end - 1, i + 1);
}

int main(void) {
  init();
  char flag[128];
  printf("Enter the flag for this challenge and I will tell me whether it's "
         "valid or not :)\n");
  printf("Flag: ");
  size_t n = read(STDIN_FILENO, flag, sizeof(flag) - 1);
  flag[n - 1] = 0;
  n -= 1;
  printf("Ok let's see ... ");
  if (validate_length(flag, flag + n - 1) &&
      validate_chars(flag, flag + n - 1, 0)) {
    printf("Woohoo that's correct! You can submit it %s\n", flag);
  } else {
    printf("Nah something went wrong. That ain't the correct flag\n");
  }
  return EXIT_SUCCESS;
}
