#include <linux/limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#define SHELLCODE_MAX 100

void timeout() {
  puts("TIMED OUT. YOUR SOLUTION IS NOT FAST ENOUGH. GOOD LUCK NEXT TIME :D");
  exit(EXIT_FAILURE);
}

void init() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  signal(SIGALRM, timeout);
  alarm(10);
}

void run_filter(char *shellcode) {
  char *banned = "/bin/sh";
  for (int i = 0; i < strlen(banned); i++) {
    void *location = memchr(shellcode, banned[i], SHELLCODE_MAX - 1);
    if (location != NULL) {
      puts("I AM SO DONE WITH YOU ALL JUST SPAMMING /bin/sh PAYLOADS. THAT IS "
           "BANNED. COME UP WITH A NEW SHELLCODE IF YOU WANT THE FLAG");
      exit(EXIT_FAILURE);
    }
  }
}

int main(void) {
  init();
  char *shellcode =
      mmap(NULL, SHELLCODE_MAX, PROT_READ | PROT_WRITE | PROT_EXEC,
           MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  printf("WHOM SHALL I EXECUTE FIRST: ");
  fgets(shellcode, SHELLCODE_MAX - 1, stdin);
  run_filter(shellcode);
  ((void (*)())shellcode)();
  return EXIT_SUCCESS;
}
