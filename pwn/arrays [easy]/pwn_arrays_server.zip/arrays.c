#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N 5

uint64_t MARKS[N];

void timeout() {
  puts("TIMED OUT. YOUR SOLUTION IS NOT FAST ENOUGH. GOOD LUCK NEXT TIME :D");
  exit(EXIT_FAILURE);
}

void init() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  signal(SIGALRM, timeout);
  alarm(10);
}

void print_marks() {
  for (int i = 0; i < N; i++) {
    printf("Subject_%d = %ld\n", i + 1, MARKS[i]);
  }
}

void win() { system("/bin/sh"); };

int main(void) {
  init();
  char choice;
  puts("WELCOME TO DJS MARKSHEET CALCULATOR.");
  puts("ENTER YOUR MARKS AND I SHALL TELL YOU YOUR PERCENTAGE.");
  for (int i = 0; i < N; i++) {
    printf("Marks in Subject_%d: ", i + 1);
    scanf("%ld", &MARKS[i]);
  }
  puts("Please check the given data:");
  print_marks();
  printf("Do you want to modify any field [y/n] ");
  while (choice != 'y' && choice != 'n') {
    choice = getchar();
  }
  if (choice == 'y') {
    int index;
    uint64_t marks;
    printf("Which subject to edit (1-5) : ");
    scanf("%d", &index);
    index -= 1; // Zero index it
    printf("Marks : ");
    scanf("%ld", &marks);
    MARKS[index] = marks;
    puts("Ok modified. Check it now");
  }
  print_marks();
  double sum = 0;
  for (int i = 0; i < N; i++) {
    sum += MARKS[i];
  }
  printf("Your percentage would be : %.02f\n", sum / N);
  return EXIT_SUCCESS;
}
