#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

time_t seed;
unsigned char cookie_backup[64];

void timeout() {
  puts("TIMED OUT. YOUR SOLUTION IS NOT FAST ENOUGH. GOOD LUCK NEXT TIME :D");
  exit(EXIT_FAILURE);
}

void init() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  signal(SIGALRM, timeout);
  alarm(10);
  seed = time(0) >> 5;
  srand(seed);
}

void gadgets() { asm("mov %rbp, %rdi;ret"); }

int main(void) {
  init();
  unsigned char cookie[64];
  unsigned char input[100];
  for (int i = 0; i < 64; i++) {
    unsigned char val = 'A' + (rand() % 26);
    cookie[i] = val;
    cookie_backup[i] = val;
  }
  puts(
      "The rest of the challenges were defeated because they did not have \n"
      "default protections enabled. Particularly stack cookies are a serious \n"
      "issue in software exploitation.\n");
  puts("Someone said that a x86-64 program stack cookie will have 7bytes of \n"
       "randomness + 1 null byte of wastage. Here I will make my custom \n"
       "implementation of cookie with 512 bits of randomness. Let's see how "
       "you tackle this challenge.\n");
  printf("Go head, speak into the void: ");
  scanf("%s", input);
  if (memcmp(cookie, cookie_backup, 64)) {
    puts("[ALERT] COOKIE IS TAMPERED! ABORTING...");
    exit(EXIT_FAILURE);
  }
  return EXIT_SUCCESS;
}
