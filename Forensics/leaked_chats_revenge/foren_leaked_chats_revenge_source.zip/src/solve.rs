use std::{
    fs::{File, OpenOptions},
    io::{self, Read, Write},
};

use aes_gcm::{aead::Aead, Aes256Gcm, Key, KeyInit};

fn main() -> io::Result<()> {
    let mut file = File::open("protocol.dump")?;
    let mut contents = Vec::new();
    file.read_to_end(&mut contents)?;
    let nonce_start = contents.len() - (32 + 12);
    let key_start = contents.len() - 32;
    let enc = &contents[..nonce_start];
    let nonce = &contents[nonce_start..key_start];
    let key = &contents[key_start..];
    let key: &Key<Aes256Gcm> = key.into();
    let cipher = Aes256Gcm::new(&key);
    let plaintext = cipher.decrypt(nonce.into(), enc).unwrap();
    file = OpenOptions::new()
        .create_new(true)
        .write(true)
        .open("flag")
        .unwrap();
    file.write_all(&plaintext)?;
    Ok(())
}
